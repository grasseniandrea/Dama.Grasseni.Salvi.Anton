namespace esercizio3
{
    public partial class Form1 : Form
    {
        private List<int> numeri = new List<int>();
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string operazione = textBox2.Text;
            int numero;
            if (int.TryParse(textBox3.Text, out numero))
            {
                if (operazione == "cerca")
                {
                    int occorrenze = numeri.Count(n => n == numero);
                    MessageBox.Show($"Il numero {numero} � presente {occorrenze} volte nell'array.");
                }
                else if (operazione == "incrementa")
                {
                    numeri = numeri.Select(n => n + numero).ToList();
                    listBox1.Items.Clear();
                    
                }
                else
                {
                    MessageBox.Show("Operazione non valida. Inserisci cerca o incrementa.");
                }
            }
            else
            {
                MessageBox.Show("Inserisci un numero valido.");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (numeri.Count < 1000 && int.TryParse(textBox1.Text, out int numero))
            {
                numeri.Add(numero);
                listBox1.Items.Add(numero);

               
                int minimo = numeri.Min();
                int massimo = numeri.Max();

                label2.Text = "Minimo: " + minimo;
                label3.Text = "Massimo: " + massimo;
            }
            else
            {
                MessageBox.Show("Inserisci un numero valido.");
            }
        }
    }
}