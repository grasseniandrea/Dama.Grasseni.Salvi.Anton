﻿using Microsoft.VisualBasic.Devices;
using System.Security.AccessControl;

namespace damaaaa
{
    public partial class Form1 : Form
    {
        private const int DIMENSIONE_SCACCHIERA = 8;
        private const int DIMENSIONE_CASELLA = 50;
        private Button[,] caselle = new Button[DIMENSIONE_SCACCHIERA, DIMENSIONE_SCACCHIERA];
        private Scacchiera scacchiera = new Scacchiera();
        private bool turno = false;//false turno bianco true turno nero
        private bool mossa = false;
        private bool click = false;
        private int x, y;

        public Form1()
        {
            InitializeComponent();
        }
        private void InizializzaScacchiera()
        {
            // Imposta le dimensioni del form in base alla dimensione della scacchiera
            this.Size = new Size(DIMENSIONE_SCACCHIERA * DIMENSIONE_CASELLA + 20, DIMENSIONE_SCACCHIERA * DIMENSIONE_CASELLA + 40);

            // Crea i pulsanti (caselle) per la scacchiera
            for (int riga = 0; riga < DIMENSIONE_SCACCHIERA; riga++)
            {
                for (int colonna = 0; colonna < DIMENSIONE_SCACCHIERA; colonna++)
                {
                    Button casella = new Button();
                    casella.Size = new Size(DIMENSIONE_CASELLA, DIMENSIONE_CASELLA);
                    casella.Location = new Point(colonna * DIMENSIONE_CASELLA, riga * DIMENSIONE_CASELLA);
                    casella.BackColor = (riga + colonna) % 2 == 0 ? Color.White : Color.Black;
                    casella.Click += Casella_Click;
                    this.Controls.Add(casella);
                    caselle[riga, colonna] = casella;
                }
            }
            PosizionaPezziIniziali();
        }

        private void PosizionaPezziIniziali()
        {
            // Posiziona le pedine bianche
            for (int riga = 0; riga < 3; riga++)
            {
                for (int colonna = (riga + 1) % 2; colonna < 8; colonna += 2)
                {
                    pedina pedinaBianca = new pedina(Pezzo.Colore.White, riga, colonna, scacchiera);
                    pedinaBianca.riga1 = riga;
                    pedinaBianca.colonna1 = colonna;
                    scacchiera.PosizionaPedina(riga, colonna, pedinaBianca);
                    caselle[riga, colonna].BackgroundImage = Image.FromFile("immaginipedine/pedinabianca.png");
                    caselle[riga, colonna].BackgroundImageLayout = ImageLayout.Stretch;
                }
            }

            // Posiziona le pedine nere
            for (int riga = 5; riga < 8; riga++)
            {
                for (int colonna = (riga + 1) % 2; colonna < 8; colonna += 2)
                {
                    pedina pedinaNera = new pedina(Pezzo.Colore.Black, riga, colonna, scacchiera);
                    pedinaNera.riga1 = riga;
                    pedinaNera.colonna1 = colonna;
                    scacchiera.PosizionaPedina(riga, colonna, pedinaNera);
                    caselle[riga, colonna].BackgroundImage = Image.FromFile("immaginipedine/pedinanegra.png");
                    caselle[riga, colonna].BackgroundImageLayout = ImageLayout.Stretch;
                }
            }
        }
        private Pezzo pezzoSelezionato; // Variabile per memorizzare il pezzo selezionato
        private bool turnoBianco = true; // Variabile per tenere traccia di chi è il turno

       
        private void Casella_Click(object sender, EventArgs e)
        {
            Button casellaCliccata = (Button)sender;
            int colonnaCliccata = getRowColFromLocation(casellaCliccata.Location).Item1;
            int rigaCliccata = getRowColFromLocation(casellaCliccata.Location).Item2;

            // Controllo se la casella cliccata contiene una pedina
            pedina pedinaSelezionata = (pedina)scacchiera.GetPedina(rigaCliccata, colonnaCliccata);
            if (pedinaSelezionata != null)
            {
                // Memorizzo la pedina selezionata
                pezzoSelezionato = pedinaSelezionata;
            }
            else
            {
                if (pezzoSelezionato != null)
                {
                    try
                    {
                        // Esegue il movimento
                        (int, int) vecchiaposizione = (pezzoSelezionato.riga1, pezzoSelezionato.colonna1);
                        scacchiera.RimuoviPedina(pezzoSelezionato.riga1, pezzoSelezionato.colonna1);
                        pezzoSelezionato.muovi(rigaCliccata, colonnaCliccata);
                        pezzoSelezionato.riga1 = rigaCliccata;
                        pezzoSelezionato.colonna1 = colonnaCliccata;
                        scacchiera.PosizionaPedina(pezzoSelezionato.riga1, pezzoSelezionato.colonna1, null);
                        scacchiera.PosizionaPedina(pezzoSelezionato.riga1, pezzoSelezionato.colonna1, pezzoSelezionato);

                        // Aggiorna l'interfaccia utente
                        UpdateUI(vecchiaposizione.Item1, vecchiaposizione.Item2, null);
                        UpdateUI(rigaCliccata, colonnaCliccata, pezzoSelezionato);

                        // Cambia il turno
                        turnoBianco = !turnoBianco;
                    }
                    catch (ArgumentException ex)
                    {
                        MessageBox.Show(ex.Message);
                    }

                    // Resetta la pedina selezionata
                    pezzoSelezionato = null;
                }
            
        }
        }

     

        public (int, int) getRowColFromLocation(Point point)
        {
            return ((point.X ) / DIMENSIONE_CASELLA, (point.Y) / DIMENSIONE_CASELLA);
        }
        private void UpdateUI(int riga, int colonna, Pezzo pezzo)
        {
            Button casella = (Button)caselle[riga, colonna];
            if (pezzo == null)
            {
                casella.BackgroundImage = null;
                casella.Text = "";
            }
            else
            {
                if (pezzo.colore1 == Pezzo.Colore.White)
                {
                    casella.BackgroundImage = Image.FromFile("immaginipedine/pedinabianca.png");
                }
                else
                {
                    casella.BackgroundImage = Image.FromFile("immaginipedine/pedinanegra.png");
                }
                casella.BackgroundImageLayout = ImageLayout.Stretch;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {


        }

        private void Form1_Load(object sender, EventArgs e)
        {
            InizializzaScacchiera();
        }
    }
}
/*turno = !turno; 
           Button b = (Button)sender;
           pedina p;
           p = (pedina)scacchiera.SCACCHIERA[x,y];
           if( p == null)
           {
               try
               {
                   scacchiera.posizionaPedina(getRowColFromLocation(b.Location).Item2, getRowColFromLocation(b.Location).Item1, scacchiera.SCACCHIERA[x, y]);
                   scacchiera.rimuoviPedina(x, y);
               }
               catch
               {
                   MessageBox.Show("NON HAI SELEZIONATO UNA PEDINA");
               }
           }
           else 
           {
               x = getRowColFromLocation(b.Location).Item2;
               y = getRowColFromLocation(b.Location).Item1;
               MessageBox.Show("csdhoc");
           }
           */