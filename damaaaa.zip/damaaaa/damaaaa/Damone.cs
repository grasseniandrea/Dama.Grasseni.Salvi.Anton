﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static damaaaa.Pezzo;

namespace damaaaa
{
    public class Damone : Pezzo
    {
        public Damone(Colore colore, int riga, int colonna, Scacchiera scacchiera) : base(colore, riga, colonna, scacchiera)
        {
        }

        public override void muovi(int nuovaRiga, int nuovaColonna)
        {
            base.muovi(nuovaRiga, nuovaColonna);


            int deltaRiga = nuovaRiga - riga;
            int deltaColonna = nuovaColonna - colonna;


            if (Math.Abs(deltaRiga) != Math.Abs(deltaColonna))
            {
                throw new ArgumentException("Mossa non valida per il pezzo");
            }
            if (Math.Abs(nuovaRiga - riga) != Math.Abs(nuovaColonna - colonna))
            {
                throw new ArgumentException("Mossa non valida per il pezzo: deve essere in diagonale");
            }
            int stepRiga = deltaRiga > 0 ? 1 : -1;
            int stepColonna = deltaColonna > 0 ? 1 : -1;
            int rigaTemp = riga + stepRiga;
            int colonnaTemp = colonna + stepColonna;

            if (Math.Abs(deltaColonna) == 1)
            {
                if (scacchiera.GetPedina(riga, colonna + deltaColonna) == null)
                {
                    scacchiera.RimuoviPedina(riga, colonna);
                    colonna += deltaColonna;
                    scacchiera.PosizionaPedina(riga, colonna, this);
                }
                else
                {
                    throw new ArgumentException("Pedina nel mezzo");
                }
            }


            scacchiera.RimuoviPedina(riga, colonna);
            riga = nuovaRiga;
            colonna = nuovaColonna;
            scacchiera.PosizionaPedina(riga, colonna, this);
        }

        public override void mangia(int r, int c)
        {
            if (scacchiera.GetPedina(r, c) == null)
            {
                throw new ArgumentException("Nessuna pedina da mangiare in quella posizione");
            }

            int deltaRiga = r - this.riga;
            int deltaColonna = c - this.colonna;

            if (Math.Abs(deltaRiga) != Math.Abs(deltaColonna))
            {
                throw new ArgumentException("Mossa non valida per il pezzo");
            }

            int stepRiga = deltaRiga > 0 ? 1 : -1;
            int stepColonna = deltaColonna > 0 ? 1 : -1;

            int rigaTemp = this.riga + stepRiga;
            int colonnaTemp = this.colonna + stepColonna;

            while (rigaTemp != r || colonnaTemp != c)
            {
                scacchiera.RimuoviPedina(rigaTemp, colonnaTemp);
                rigaTemp += stepRiga;
                colonnaTemp += stepColonna;
            }

            scacchiera.RimuoviPedina(r, c);
            scacchiera.PosizionaPedina(this.riga, this.colonna, null);
            this.riga = r;
            this.colonna = c;
            scacchiera.PosizionaPedina(r, c, this);
        }

        public override void trasforma(Pezzo p)
        {
            throw new NotImplementedException();
        }

        public override string stampa()
        {
            return "⛁";
        }
    }
}
