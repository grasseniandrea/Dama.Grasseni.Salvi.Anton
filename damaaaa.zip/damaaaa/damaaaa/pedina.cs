﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace damaaaa
{
    public class pedina : Pezzo
    {
        public pedina(Colore colore, int riga, int colonna, Scacchiera scacchiera) : base(colore, riga, colonna, scacchiera)
        {
        }
        public override void muovi(int nuovaRiga, int nuovaColonna)
        {
            base.muovi(nuovaRiga, nuovaColonna);

            int deltaRiga = nuovaRiga - riga;
            int deltaColonna = nuovaColonna - colonna;

            if (Math.Abs(deltaRiga) != Math.Abs(deltaColonna))
            {
                throw new ArgumentException("Mossa non valida per il pezzo");
            }
            if (Math.Abs(nuovaRiga - riga) != Math.Abs(nuovaColonna - colonna))
            {
                throw new ArgumentException("Mossa non valida per il pezzo: deve essere in diagonale");
            }

            int stepRiga = deltaRiga > 0 ? 1 : -1;
            int stepColonna = deltaColonna > 0 ? 1 : -1;
            int rigaTemp = riga + stepRiga;
            int colonnaTemp = colonna + stepColonna;

            if (Math.Abs(deltaColonna) == 1)
            {
                if (rigaTemp != nuovaRiga)
                {
                    throw new ArgumentException("Mossa non valida per il pezzo: deve essere in diagonale");
                }

                if (scacchiera.GetPedina(rigaTemp, colonnaTemp) == null)
                {
                    scacchiera.RimuoviPedina(riga, colonna);
                    colonna += deltaColonna;
                    scacchiera.PosizionaPedina(riga, colonna, this);
                }
                else
                {
                    throw new ArgumentException("Pedina nel mezzo");
                }
            }

            if (scacchiera.GetPedina(nuovaRiga, nuovaColonna) != null)
            {
                throw new ArgumentException("Pedina nel mezzo");
            }

            scacchiera.RimuoviPedina(riga, colonna);
            riga = nuovaRiga;
            colonna = nuovaColonna;
            scacchiera.PosizionaPedina(riga, colonna, this);

            if (colore == Colore.White && nuovaRiga == 0)
            {
                trasforma(new pedina(colore, nuovaRiga, nuovaColonna, scacchiera));
            }
            else if (colore == Colore.Black && nuovaRiga == 7)
            {
                trasforma(new pedina(colore, nuovaRiga, nuovaColonna, scacchiera));
            }
        }

        public override void mangia(int r, int c)
        {
            if (scacchiera.GetPedina(r, c) == null || scacchiera.GetPedina(r, c).colore1 == colore)
            {
                throw new ArgumentException("Mossa non valida: non è possibile mangiare una pedina dello stesso colore o una casella vuota");
            }

            int deltaRiga = r - riga;
            int deltaColonna = c - colonna;

            if (Math.Abs(deltaRiga) != 1 || Math.Abs(deltaColonna) != 1)
            {
                throw new ArgumentException("Mossa non valida: è possibile mangiare solo una pedina in diagonale");
            }

            scacchiera.RimuoviPedina(r, c);
            scacchiera.RimuoviPedina(riga, colonna);
            riga = r;
            colonna = c;
            scacchiera.PosizionaPedina(riga, colonna, this);
        }
       

        public override void trasforma(Pezzo p)
        {
            if (p is Damone)
            {
                Damone damone = (Damone)p;
                scacchiera.RimuoviPedina(riga, colonna);
                scacchiera.PosizionaPedina(riga, colonna, damone);
            }
            else
            {
                throw new ArgumentException("Il pezzo non è un Damone");
            }
        }
        
        public override string stampa()
        {
            return "";
        }
    }
}//⛀
