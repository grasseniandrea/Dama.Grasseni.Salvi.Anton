﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace damaaaa
{
    public abstract class Pezzo
    {
        public enum Colore
        {
            Black,
            White,
        }

        protected Scacchiera scacchiera;
        protected Colore colore;
        protected int riga;
        protected int colonna;
        private bool viva;

        public Colore colore1 { get => colore; }
        public int colonna1 { get; set; }
        public int riga1 { get; set; }
        public Pezzo(Colore colore, int riga, int colonna, Scacchiera scacchiera)
        {
            this.colore = colore;
            this.riga = riga;
            this.colonna = colonna;
            this.scacchiera = scacchiera;
            viva = true;

        }

        public virtual void muovi(int nuovaRiga, int nuovaColonna)
        {

            if (nuovaRiga < 0 || nuovaRiga > 7)
            {
                throw new ArgumentException("Posizione non valida");
            }
            if (nuovaColonna < 0 || nuovaColonna > 7)
            {
                throw new ArgumentException("Posizione non valida");
            }
            Pezzo p = scacchiera.GetPedina(nuovaRiga, nuovaColonna);
            if (p != null && p.colore == colore)
            {
                throw new ArgumentException("Casella occupata da una pedina del tuo stesso colore");
            }
        }

        public abstract void mangia(int r, int c);


        public abstract void trasforma(Pezzo p);

        
        public abstract string stampa();
    }
}
