﻿    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    namespace damaaaa
    {
        public class Scacchiera
        {
            private Pezzo[,] scacchiera;

            public Pezzo[,] SCACCHIERA
            {
                get => scacchiera;
            }

            public Scacchiera()
            {
                scacchiera = new Pezzo[8, 8];
            }

            public void PosizionaPedina(int r, int c, Pezzo p)
            {
                ControllaCoordinate(r, c);
                scacchiera[r, c] = p;
            }

            public void RimuoviPedina(int r, int c)
            {
                ControllaCoordinate(r, c);
                scacchiera[r, c] = null;
            }

            public Pezzo GetPedina(int r, int c)
            {
                ControllaCoordinate(r, c);
                return scacchiera[r, c];
            }

            private void ControllaCoordinate(int r, int c)
            {
                if (r < 0 || r > 7)
                {
                    throw new ArgumentException("riga non valida");
                }
                if (c < 0 || c > 7)
                {
                    throw new ArgumentException("colonna non valida");
                }
            }

            public bool PedinaNelMezzo(int r1, int c1, int r2, int c2)
            {
                ControllaCoordinate(r1, c1);
                ControllaCoordinate(r2, c2);

                if (r1 == r2 && c1 == c2)
                {
                    throw new ArgumentException("posizione iniziale e finale coincidenti");
                }

                if (r1 != r2 && c1 != c2 && Math.Abs(r2 - r1) != Math.Abs(c2 - c1))
                {
                    throw new ArgumentException("le posizioni non sono allineate in obliquo");
                }

                int dirR = (r1 == r2 ? 0 : (r2 > r1 ? 1 : -1));
                int dirC = (c1 == c2 ? 0 : (c2 > c1 ? 1 : -1));
                int deltaR = Math.Abs(r2 - r1);
                int deltaC = Math.Abs(c2 - c1);
                int nPassi = Math.Max(deltaR, deltaC);
                for (int passo = 1; passo <= nPassi; passo++)
                {
                    int r = r1 + (dirR * passo);
                    int c = c1 + (dirC * passo);
                    if (scacchiera[r, c] != null) return true;
                }
                return false;
            }

            public bool VerificaMossaValida(Button b)
            {
                if (b == null)
                {
                    MessageBox.Show("NON HAI SELEZIONATO UNA PEDINA");
                    return false;
                }

                int x = GetRowColFromLocation(b.Location).Item2;
                int y = GetRowColFromLocation(b.Location).Item1;

                int nR = GetRowColFromLocation(Control.MousePosition).Item1;
                int nC = GetRowColFromLocation(Control.MousePosition).Item2;

                if (PedinaNelMezzo(x, y, nR, nC))
                {
                    return true;
                }
                else
                {
                    MessageBox.Show("MOSSA NON VALIDA");
                    return false;
                }
            }

            public Tuple<int, int> GetRowColFromLocation(Point p)
            {
                int x = (int)((p.X - 32) / 50);
                int y = (int)((p.Y - 32) / 50);
                return new Tuple<int, int>(y, x);
            }
        }

    }

